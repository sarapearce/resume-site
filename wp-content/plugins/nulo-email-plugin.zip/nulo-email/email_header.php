<!-- saved from url=(0079)https://www.smashingmagazine.com/wp-content/uploads/2011/07/email_template.html -->
<html style="background:#444"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		
		<title><?php echo $email_subject ?></title>
	
	</head>
	<body style="">
		<div id="email_container">
			<div style="width:570px; padding:0 0 0 20px; margin:50px auto 12px auto" id="email_header">
				<span style="background:#585858; color:#fff; padding:12px;font-family:trebuchet ms; letter-spacing:1px; 
					-moz-border-radius-topleft:5px; -webkit-border-top-left-radius:5px; 
					border-top-left-radius:5px;moz-border-radius-topright:5px; -webkit-border-top-right-radius:5px; 
					border-top-right-radius:5px;">
					MyAwesomeWebsite.com
				</span></div>
			</div>